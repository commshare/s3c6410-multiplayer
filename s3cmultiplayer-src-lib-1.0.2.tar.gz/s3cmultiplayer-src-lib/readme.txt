install:

Copy alsa to /usr/alsa........
Copy lib to /lib.......

Source code:

please refer to cross to cross compile SDL, alsa, tslib and ffmpeg to install /usr/Embedded.




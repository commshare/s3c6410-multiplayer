#ifndef __PARSE_H264_SPSPPS_H
#define __PARSE_H264_SPSPPS_H


#ifdef __cplusplus
extern "C"{
#endif

int ParseH264SPSPPS(const char* buf,int size,char *outbuf);

#ifdef __cplusplus
}
#endif

#endif

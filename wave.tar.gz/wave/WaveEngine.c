#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/soundcard.h>
#include <unistd.h>
#include <sys/soundcard.h>
#include <alsa/asoundlib.h>

#include "WaveEngine.h"

#define FALSE 	0
#define TRUE	1

enum {
	INIT = -1,
	PAUSE = 0,
	PLAY = 1
};

typedef struct AlsaMixer
{
	snd_mixer_t *mixerFd;
	snd_mixer_elem_t *elem;
}AlsaMixer;

typedef struct AlsaParam
{
	snd_pcm_t *m_bDeviceID;
	int rate;
	int format;
	int channels;

	int frames;
	int base;

	int state;
}AlsaParam;

static AlsaParam Alp;
static UseAlsaNum = 0;

#define ALSA_SOUND_COMMON_SAMPLE	16
#define ALSA_SOUND_COMMON_BITLEN	8

#define ALSA_SOUND_VOL_MIN	0
#define ALSA_SOUND_VOL_MAX	100

#define GET_ALSA_FRAME_SIZE(a,b)	((a)/(b))

static int Format2ALSA(int format)
{
	switch(format)
	{
	case SAMPLE_FMT_NONE:
		return SND_PCM_FORMAT_S16_LE;
	case SAMPLE_FMT_U8:
		return SND_PCM_FORMAT_U8;
	case SAMPLE_FMT_S16:
		return SND_PCM_FORMAT_S16_LE;
	case SAMPLE_FMT_S32:
		return SND_PCM_FORMAT_S32_LE;
	case SAMPLE_FMT_FLT:
		return SND_PCM_FORMAT_FLOAT_LE;
	case SAMPLE_FMT_DBL:
		return SND_PCM_FORMAT_FLOAT64_LE;
	}

	return SND_PCM_FORMAT_S16_LE;
}

static int GetSampleBitFromFormat(int format)
{
	switch(format)
	{
	case SAMPLE_FMT_NONE:
		return ALSA_SOUND_COMMON_SAMPLE;
	case SAMPLE_FMT_U8:
		return 8;
	case SAMPLE_FMT_S16:
		return 16;
	case SAMPLE_FMT_S32:
		return 32;
	case SAMPLE_FMT_FLT:
		return 32;
	case SAMPLE_FMT_DBL:
		return 64;
	}

	return ALSA_SOUND_COMMON_SAMPLE;
}

static int xrun_recovery(snd_pcm_t *handle, int err)
{
	if (err == -EPIPE) 
	{
      	err = snd_pcm_prepare(handle);

		if (err < 0)
		{
			printf("Can't recovery from underrun, prepare failed: %s\n",snd_strerror(err));
			return 0;
		} 
		else if (err == -ESTRPIPE) 
		{
			while ((err = snd_pcm_resume(handle)) == -EAGAIN)
				sleep(1);
		 	if (err < 0) 
			{
		    		err = snd_pcm_prepare(handle);
		 		if (err < 0)
		    			printf("Can't recovery from suspend, prepare failed: %s\n",snd_strerror(err));
	      		}
      		return 0;
		}	}

	return err;
}

static int operamixer(int vol,int flag)
{
	int err;
	long value;

	snd_mixer_t *handle;
	snd_mixer_elem_t *elem;
	snd_mixer_selem_id_t *sid;

	static char *mix_name = "Headphone";
	static char *card = "default";
	static int mix_index = 0;

	snd_mixer_selem_id_alloca(&sid);
	snd_mixer_selem_id_set_index(sid, mix_index);
	snd_mixer_selem_id_set_name(sid, mix_name);

	err = snd_mixer_open(&handle, 0);
	if ( err < 0 )
	{
		printf("Open mixer error!\n",snd_strerror(err));
		return -1;
	}

	err = snd_mixer_attach(handle, card);

	if ( err < 0 )
	{
		printf("Attach mixer error!\n",snd_strerror(err));
		snd_mixer_close(handle);
		return -1;
	}

	err = snd_mixer_selem_register(handle, NULL, NULL);

	if ( err < 0 )
	{
		printf("Register mixer error!\n",snd_strerror(err));
		snd_mixer_close(handle);
		return -1;
	}

	err = snd_mixer_load(handle);

	if ( err < 0 )
	{
		printf("Load mixer error!\n",snd_strerror(err));
		snd_mixer_close(handle);
		return -1;
	}


	elem = snd_mixer_find_selem(handle, sid);

	if ( !elem )
	{
		printf("Elem find mixer error!\n",snd_strerror(err));
		snd_mixer_close(handle);
		return -1;
	}

	snd_mixer_selem_get_playback_volume(elem, 0, &value);

	if ( flag == TRUE )
	{
		snd_mixer_close(handle);
		return value;
	}

	snd_mixer_selem_set_playback_volume(elem, 0, vol);
	snd_mixer_selem_set_playback_volume(elem, 1, vol);

	snd_mixer_close(handle);
}
int InitWaveEngine(int rate,int format,int channels)
{
	if(UseAlsaNum != 0)
	{
		printf("Alsa is used by others!\n");
		return FALSE;
	}

	UseAlsaNum = 1;

	long loops;
	int rc;
	snd_pcm_t *alsa_handle;

	snd_pcm_hw_params_t *alsa_hwparams = NULL;
	snd_pcm_sw_params_t *alsa_swparams = NULL;

	snd_pcm_uframes_t size, boundary;

	int dir;
	
	memset(&Alp,0,sizeof(AlsaParam));

	if((rc = snd_pcm_open(&alsa_handle, "default", SND_PCM_STREAM_PLAYBACK, 0)) < 0)
	{
		UseAlsaNum = 0;
		printf("Open alsa fail!\n");
		return FALSE;
	}

	snd_pcm_hw_params_alloca(&alsa_hwparams);
	snd_pcm_sw_params_alloca(&alsa_swparams);

	snd_pcm_hw_params_any(alsa_handle, alsa_hwparams);

	snd_pcm_hw_params_set_access(alsa_handle,alsa_hwparams,SND_PCM_ACCESS_RW_INTERLEAVED);

	snd_pcm_hw_params_set_format(alsa_handle,alsa_hwparams,Format2ALSA(format));
	snd_pcm_hw_params_set_channels(alsa_handle, alsa_hwparams, channels);
	snd_pcm_hw_params_set_rate_near(alsa_handle, alsa_hwparams, &rate, &dir);

	if((rc = snd_pcm_hw_params(alsa_handle, alsa_hwparams)) < 0)
	{
		UseAlsaNum = 0;
		printf("Set alsa fail!\n");
		return FALSE;
	}


	snd_pcm_hw_params_get_buffer_size(alsa_hwparams, &size);

	snd_pcm_sw_params_current(alsa_handle, alsa_swparams);
#if SND_LIB_VERSION >= 0x000901
	snd_pcm_sw_params_get_boundary(alsa_swparams, &boundary);
#else
	boundary = 0x7fffffff;
#endif
	snd_pcm_sw_params_set_start_threshold(alsa_handle, alsa_swparams, size);
	snd_pcm_sw_params_set_stop_threshold(alsa_handle, alsa_swparams, boundary);
#if SND_LIB_VERSION >= 0x000901
	snd_pcm_sw_params_set_silence_size(alsa_handle, alsa_swparams, boundary);
#endif
	snd_pcm_sw_params(alsa_handle, alsa_swparams);


	Alp.m_bDeviceID = alsa_handle;
	Alp.rate = rate;
	Alp.format = Format2ALSA(format);
	Alp.channels = channels;
	Alp.base = GET_ALSA_FRAME_SIZE(GetSampleBitFromFormat(format),ALSA_SOUND_COMMON_BITLEN)*Alp.channels;

	snd_pcm_prepare(Alp.m_bDeviceID);

	Alp.state = INIT;

	return TRUE;	
}

int PlayWave(uint8_t* buffer,int size)
{
	if(UseAlsaNum != 1)
		return -1;

	Alp.state = PLAY;
	Alp.frames = GET_ALSA_FRAME_SIZE(size,Alp.base);

	int err = 0;

	if((err = snd_pcm_writei(Alp.m_bDeviceID,buffer,Alp.frames)) < 0)
	{
		err = xrun_recovery(Alp.m_bDeviceID,err);

		if(err < 0)
			return -1;
	}

	return 0;
}

int PauseWave()
{
	if(UseAlsaNum != 1)
		return -1;

	if(Alp.state != PLAY)
		return -1;

	Alp.state = PAUSE;

	if(snd_pcm_pause(Alp.m_bDeviceID,Alp.state) < 0)
	{
		snd_pcm_reset(Alp.m_bDeviceID);
		snd_pcm_prepare(Alp.m_bDeviceID);	
	}

	return 0;
}

int ResumeWave()
{
	if(UseAlsaNum != 1)
		return -1;

	if(Alp.state != PAUSE)
		return -1;

	Alp.state = PLAY;

	if(snd_pcm_pause(Alp.m_bDeviceID,Alp.state) < 0)
	{
		snd_pcm_prepare(Alp.m_bDeviceID);
		snd_pcm_reset(Alp.m_bDeviceID);
	}

	return 0;
}

int ResetWave()
{
	if(UseAlsaNum != 1)
		return -1;

	return snd_pcm_reset(Alp.m_bDeviceID);
}

void UnitWaveEngine()
{
	if(UseAlsaNum != 1)
		return;

	snd_pcm_drain(Alp.m_bDeviceID);
      snd_pcm_close(Alp.m_bDeviceID);

	UseAlsaNum = 0;
}

void SetWaveVolume(int value)
{
	operamixer(value,FALSE);
}

int GetWaveVolume()
{
	return operamixer(0,TRUE);;
}

